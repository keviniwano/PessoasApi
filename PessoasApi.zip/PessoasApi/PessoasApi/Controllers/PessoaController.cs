﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using PessoasApi.Models;

namespace PessoasApi.Controllers;

[ApiController]
[Route("pessoas")]
public class PessoaController : ControllerBase
{
    private static List<Pessoa> _storage = new();
    private static int _nextId = 1;

    [HttpPost]
    public IActionResult Create([FromBody] Pessoa p)
    {
        p.Id = _nextId++;
        _storage.Add(p);
        return CreatedAtAction(nameof(GetById), new { id = p.Id }, p);
    }

    [HttpGet]
    public IActionResult GetAll() => Ok(_storage);

    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var p = _storage.FirstOrDefault(x => x.Id == id);
        return p == null ? NotFound() : Ok(p);
    }

    [HttpGet("cpf/{cpf}")]
    public IActionResult GetByCpf(string cpf)
        => Ok(_storage.FirstOrDefault(p => p.Cpf == cpf));

    [HttpPut("{id}")]
    public IActionResult Update(int id, [FromBody] Pessoa updated)
    {
        var idx = _storage.FindIndex(p => p.Id == id);
        if (idx == -1) return NotFound();
        updated.Id = id;
        _storage[idx] = updated;
        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var idx = _storage.FindIndex(p => p.Id == id);
        if (idx == -1) return NotFound();
        _storage.RemoveAt(idx);
        return NoContent();
    }

    [HttpGet("busca")]
    public IActionResult Search([FromQuery] string nome)
    {
        var res = string.IsNullOrWhiteSpace(nome)
            ? _storage
            : _storage.Where(p => p.Nome.Contains(nome, StringComparison.OrdinalIgnoreCase)).ToList();
        return Ok(res);
    }

    [HttpGet("imc")]
    public IActionResult ByImc([FromQuery] double? min, [FromQuery] double? max)
    {
        var minV = min ?? double.MinValue;
        var maxV = max ?? double.MaxValue;
        var res = _storage.Where(p => p.IMC >= minV && p.IMC <= maxV).ToList();
        return Ok(res);
    }
}